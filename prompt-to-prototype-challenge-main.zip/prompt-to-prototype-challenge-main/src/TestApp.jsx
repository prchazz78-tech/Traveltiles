import React from 'react'

function TestApp() {
  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1>Travel Tiles Test</h1>
      <p>React is working!</p>
      <button onClick={() => alert('Button clicked!')}>Test Button</button>
    </div>
  )
}

export default TestApp